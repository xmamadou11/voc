import { useEffect, useState } from 'react'
import type { VocabularyWord } from '../types/vocabulary'

interface UseVocabularyResult {
  vocabulary: VocabularyWord[]
  loading: boolean
  error: string | null
}

const REQUIRED_FIELDS = ['id', 'word', 'phonetic', 'level', 'translation'] as const

const VALID_LEVELS = ['A1', 'A2', 'B1', 'B2', 'C1', 'C2']

/**
 * Checks whether a value is a well-formed VocabularyWord, i.e. it
 * contains all required fields with the expected types.
 */
function isValidVocabularyWord(entry: unknown): entry is VocabularyWord {
  if (typeof entry !== 'object' || entry === null) {
    return false
  }

  const record = entry as Record<string, unknown>

  for (const field of REQUIRED_FIELDS) {
    if (!(field in record)) {
      return false
    }
  }

  if (typeof record.id !== 'number') {
    return false
  }

  if (typeof record.word !== 'string' || record.word.trim() === '') {
    return false
  }

  if (typeof record.phonetic !== 'string') {
    return false
  }

  if (typeof record.level !== 'string' || !VALID_LEVELS.includes(record.level)) {
    return false
  }

  if (typeof record.translation !== 'string') {
    return false
  }

  return true
}

/**
 * Filters an unknown array of vocabulary entries, keeping only valid
 * entries and logging a warning for each invalid one.
 */
function validateVocabulary(data: unknown[]): VocabularyWord[] {
  const validEntries: VocabularyWord[] = []

  data.forEach((entry, index) => {
    if (isValidVocabularyWord(entry)) {
      validEntries.push(entry)
    } else {
      console.warn(`Invalid vocabulary entry at index ${index}, skipping:`, entry)
    }
  })

  return validEntries
}

/**
 * Loads the vocabulary list from `public/vocabulary.json`.
 *
 * Exposes the loaded vocabulary array along with loading and error
 * states for use by UI components. The fetched data is validated:
 * it must be an array, and each entry must contain the required
 * fields (id, word, phonetic, level, translation) with valid values.
 * Invalid entries are filtered out and logged as warnings. An empty
 * (or fully invalid) vocabulary is handled safely, resulting in an
 * empty array rather than an error.
 */
export function useVocabulary(): UseVocabularyResult {
  const [vocabulary, setVocabulary] = useState<VocabularyWord[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const controller = new AbortController()

    async function loadVocabulary() {
      setLoading(true)
      setError(null)

      try {
        const response = await fetch(`${import.meta.env.BASE_URL}vocabulary.json`, {
          signal: controller.signal,
        })

        if (!response.ok) {
          throw new Error(`Failed to load vocabulary.json (status ${response.status})`)
        }

        const data: unknown = await response.json()

        if (!Array.isArray(data)) {
          throw new Error('vocabulary.json does not contain an array')
        }

        if (data.length === 0) {
          console.warn('vocabulary.json is empty')
          setVocabulary([])
          return
        }

        const validEntries = validateVocabulary(data)

        if (validEntries.length === 0) {
          console.warn('No valid vocabulary entries found in vocabulary.json')
        }

        setVocabulary(validEntries)
      } catch (err) {
        if (err instanceof DOMException && err.name === 'AbortError') {
          return
        }
        setError(err instanceof Error ? err.message : 'Failed to load vocabulary')
        setVocabulary([])
      } finally {
        setLoading(false)
      }
    }

    loadVocabulary()

    return () => controller.abort()
  }, [])

  return { vocabulary, loading, error }
}
