import { Link } from 'react-router-dom'

function HomePage() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center bg-slate-50 px-4 text-center">
      <h1 className="text-3xl font-bold text-slate-800">Vocabulary App</h1>
      <p className="mt-2 text-slate-500">Project scaffold ready. Features coming soon.</p>
      <Link
        to="/learn"
        className="mt-6 rounded-full bg-stone-900 px-6 py-2 text-sm font-medium text-white transition hover:bg-stone-700"
      >
        Start learning
      </Link>
    </main>
  )
}

export default HomePage
