import { useEffect, useMemo, useState } from 'react'
import { useVocabulary } from '../hooks/useVocabulary'
import VocabularyCard from '../components/VocabularyCard'
import NavigationControls from '../components/NavigationControls'
import SearchBar, { RESULTS_LIMIT } from '../components/SearchBar'
import LevelFilter, { type LevelFilterValue } from '../components/LevelFilter'
import type { VocabularyWord } from '../types/vocabulary'

function LearnPage() {
  const { vocabulary, loading, error } = useVocabulary()
  const [currentIndex, setCurrentIndex] = useState(0)
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedLevel, setSelectedLevel] = useState<LevelFilterValue>('ALL')

  const filteredVocabulary = useMemo(() => {
    if (selectedLevel === 'ALL') {
      return vocabulary
    }
    return vocabulary.filter((entry) => entry.level === selectedLevel)
  }, [vocabulary, selectedLevel])

  const hasWords = filteredVocabulary.length > 0
  const isFirst = currentIndex === 0
  const isLast = currentIndex === filteredVocabulary.length - 1

  const goToPrevious = () => {
    setCurrentIndex((index) => Math.max(0, index - 1))
  }

  const goToNext = () => {
    setCurrentIndex((index) => Math.min(filteredVocabulary.length - 1, index + 1))
  }

  const handleSelectLevel = (level: LevelFilterValue) => {
    setSelectedLevel(level)
    setCurrentIndex(0)
    setSearchQuery('')
  }

  const allMatches = useMemo(() => {
    const normalizedQuery = searchQuery.trim().toLowerCase()

    if (normalizedQuery === '') {
      return []
    }

    return filteredVocabulary.filter((entry) => {
      return (
        entry.word.toLowerCase().includes(normalizedQuery) ||
        entry.translation.toLowerCase().includes(normalizedQuery)
      )
    })
  }, [filteredVocabulary, searchQuery])

  const visibleMatches = useMemo(() => allMatches.slice(0, RESULTS_LIMIT), [allMatches])

  const handleSelectResult = (entry: VocabularyWord) => {
    const index = filteredVocabulary.findIndex((item) => item.id === entry.id)
    if (index !== -1) {
      setCurrentIndex(index)
    }
    setSearchQuery('')
  }

  // Keep currentIndex within bounds whenever the filtered list shrinks
  // (e.g. switching to a level with fewer words than the current index).
  useEffect(() => {
    if (filteredVocabulary.length === 0) {
      if (currentIndex !== 0) {
        setCurrentIndex(0)
      }
      return
    }

    if (currentIndex > filteredVocabulary.length - 1) {
      setCurrentIndex(filteredVocabulary.length - 1)
    }
  }, [filteredVocabulary, currentIndex])

  useEffect(() => {
    if (!hasWords) {
      return
    }

    function handleKeyDown(event: KeyboardEvent) {
      const target = event.target as HTMLElement | null
      if (target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA')) {
        return
      }

      if (event.key === 'ArrowLeft') {
        goToPrevious()
      } else if (event.key === 'ArrowRight') {
        goToNext()
      }
    }

    window.addEventListener('keydown', handleKeyDown)

    return () => {
      window.removeEventListener('keydown', handleKeyDown)
    }
  }, [hasWords, filteredVocabulary.length])

  if (loading) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-stone-50 px-4">
        <p role="status" className="text-stone-500">
          Loading vocabulary…
        </p>
      </main>
    )
  }

  if (error) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-stone-50 px-4">
        <div role="alert" className="max-w-md text-center">
          <h1 className="text-lg font-semibold text-stone-900">Couldn&apos;t load vocabulary</h1>
          <p className="mt-2 text-sm text-stone-500">{error}</p>
        </div>
      </main>
    )
  }

  if (vocabulary.length === 0) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-stone-50 px-4">
        <div className="max-w-md text-center">
          <h1 className="text-lg font-semibold text-stone-900">No words yet</h1>
          <p className="mt-2 text-sm text-stone-500">
            The vocabulary list is empty. Add some words to get started.
          </p>
        </div>
      </main>
    )
  }

  return (
    <main className="flex min-h-screen flex-col items-center bg-stone-50 px-4 py-12 sm:px-6">
      <div className="w-full max-w-xl">
        <LevelFilter selectedLevel={selectedLevel} onSelectLevel={handleSelectLevel} />

        <div className="mt-6">
          <SearchBar
            query={searchQuery}
            onQueryChange={setSearchQuery}
            results={visibleMatches}
            totalMatches={allMatches.length}
            onSelectResult={handleSelectResult}
          />
        </div>

        {hasWords ? (
          <>
            <p
              className="mb-4 mt-8 text-center text-sm font-medium uppercase tracking-widest text-stone-400"
              aria-live="polite"
            >
              {currentIndex + 1} / {filteredVocabulary.length}
            </p>
            <VocabularyCard entry={filteredVocabulary[currentIndex]} />
            <NavigationControls
              onPrevious={goToPrevious}
              onNext={goToNext}
              isFirst={isFirst}
              isLast={isLast}
            />
          </>
        ) : (
          <div className="mt-8 rounded-2xl border border-stone-200 bg-white p-8 text-center">
            <h1 className="text-lg font-semibold text-stone-900">No words at this level</h1>
            <p className="mt-2 text-sm text-stone-500">
              Try selecting a different CEFR level.
            </p>
          </div>
        )}
      </div>
    </main>
  )
}

export default LearnPage
