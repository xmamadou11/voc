import type { CEFRLevel } from '../types/vocabulary'

export type LevelFilterValue = CEFRLevel | 'ALL'

interface LevelFilterProps {
  selectedLevel: LevelFilterValue
  onSelectLevel: (level: LevelFilterValue) => void
}

const LEVELS: LevelFilterValue[] = ['ALL', 'A1', 'A2', 'B1', 'B2', 'C1', 'C2']

function LevelFilter({ selectedLevel, onSelectLevel }: LevelFilterProps) {
  return (
    <div
      role="group"
      aria-label="Filter vocabulary by CEFR level"
      className="flex w-full flex-wrap justify-center gap-2"
    >
      {LEVELS.map((level) => {
        const isActive = level === selectedLevel
        const label = level === 'ALL' ? 'All' : level

        return (
          <button
            key={level}
            type="button"
            onClick={() => onSelectLevel(level)}
            aria-pressed={isActive}
            className={`rounded-full px-4 py-2 text-sm font-semibold uppercase tracking-wide transition focus:outline-none focus:ring-2 focus:ring-stone-300 ${
              isActive
                ? 'bg-stone-900 text-white'
                : 'bg-white text-stone-600 ring-1 ring-inset ring-stone-300 hover:bg-stone-100'
            }`}
          >
            {label}
          </button>
        )
      })}
    </div>
  )
}

export default LevelFilter
