interface NavigationControlsProps {
  onPrevious: () => void
  onNext: () => void
  isFirst: boolean
  isLast: boolean
}

function NavigationControls({ onPrevious, onNext, isFirst, isLast }: NavigationControlsProps) {
  return (
    <div className="mt-6 flex w-full items-center justify-between gap-4">
      <button
        type="button"
        onClick={onPrevious}
        disabled={isFirst}
        aria-label="Previous word"
        className="flex-1 rounded-full border border-stone-300 bg-white px-6 py-3 text-sm font-medium text-stone-700 transition hover:bg-stone-100 disabled:cursor-not-allowed disabled:opacity-40 disabled:hover:bg-white sm:flex-none sm:px-8"
      >
        ← Previous
      </button>

      <button
        type="button"
        onClick={onNext}
        disabled={isLast}
        aria-label="Next word"
        className="flex-1 rounded-full bg-stone-900 px-6 py-3 text-sm font-medium text-white transition hover:bg-stone-700 disabled:cursor-not-allowed disabled:opacity-40 disabled:hover:bg-stone-900 sm:flex-none sm:px-8"
      >
        Next →
      </button>
    </div>
  )
}

export default NavigationControls
