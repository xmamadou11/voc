import { useId } from 'react'
import type { VocabularyWord } from '../types/vocabulary'

interface SearchBarProps {
  query: string
  onQueryChange: (query: string) => void
  results: VocabularyWord[]
  totalMatches: number
  onSelectResult: (entry: VocabularyWord) => void
}

const RESULTS_LIMIT = 20

function SearchBar({ query, onQueryChange, results, totalMatches, onSelectResult }: SearchBarProps) {
  const listboxId = useId()

  const showResults = query.trim() !== ''

  return (
    <div className="w-full">
      <div className="relative">
        <label htmlFor="vocabulary-search" className="sr-only">
          Search vocabulary by word or translation
        </label>
        <input
          id="vocabulary-search"
          type="search"
          value={query}
          onChange={(event) => onQueryChange(event.target.value)}
          placeholder="Search by word or translation…"
          autoComplete="off"
          role="combobox"
          aria-expanded={showResults}
          aria-controls={listboxId}
          className="w-full rounded-full border border-stone-300 bg-white px-5 py-3 pr-12 text-base text-stone-800 shadow-sm placeholder:text-stone-400 focus:border-stone-500 focus:outline-none focus:ring-2 focus:ring-stone-300"
        />
        {query !== '' && (
          <button
            type="button"
            onClick={() => onQueryChange('')}
            aria-label="Clear search"
            className="absolute right-2 top-1/2 -translate-y-1/2 rounded-full p-2 text-stone-400 transition hover:bg-stone-100 hover:text-stone-600 focus:outline-none focus:ring-2 focus:ring-stone-300"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 20 20"
              fill="currentColor"
              className="h-5 w-5"
              aria-hidden="true"
            >
              <path
                fillRule="evenodd"
                d="M5.22 5.22a.75.75 0 0 1 1.06 0L10 8.94l3.72-3.72a.75.75 0 1 1 1.06 1.06L11.06 10l3.72 3.72a.75.75 0 1 1-1.06 1.06L10 11.06l-3.72 3.72a.75.75 0 0 1-1.06-1.06L8.94 10 5.22 6.28a.75.75 0 0 1 0-1.06Z"
                clipRule="evenodd"
              />
            </svg>
          </button>
        )}
      </div>

      {showResults && (
        <div
          id={listboxId}
          role="listbox"
          aria-label="Search results"
          className="mt-3 max-h-80 overflow-y-auto rounded-2xl border border-stone-200 bg-white shadow-sm"
        >
          {results.length === 0 ? (
            <p className="px-4 py-3 text-sm text-stone-500">No matching words found.</p>
          ) : (
            <>
              <ul className="divide-y divide-stone-100">
                {results.map((entry) => (
                  <li key={entry.id} role="option" aria-selected="false">
                    <button
                      type="button"
                      onClick={() => onSelectResult(entry)}
                      className="flex w-full items-center justify-between gap-3 px-4 py-3 text-left transition hover:bg-stone-50 focus:bg-stone-50 focus:outline-none"
                    >
                      <span className="min-w-0">
                        <span className="block truncate font-medium text-stone-800">
                          {entry.word}
                        </span>
                        <span className="block truncate text-sm text-stone-500">
                          {entry.translation}
                        </span>
                      </span>
                      <span className="shrink-0 rounded-full bg-stone-100 px-2.5 py-1 text-xs font-semibold uppercase tracking-wide text-stone-600">
                        {entry.level}
                      </span>
                    </button>
                  </li>
                ))}
              </ul>
              {totalMatches > RESULTS_LIMIT && (
                <p className="border-t border-stone-100 px-4 py-2 text-center text-xs text-stone-400">
                  Showing {RESULTS_LIMIT} of {totalMatches} matches
                </p>
              )}
            </>
          )}
        </div>
      )}
    </div>
  )
}

export default SearchBar
export { RESULTS_LIMIT }
