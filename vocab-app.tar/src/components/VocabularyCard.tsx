import type { VocabularyWord } from '../types/vocabulary'

interface VocabularyCardProps {
  entry: VocabularyWord
}

const LEVEL_STYLES: Record<VocabularyWord['level'], string> = {
  A1: 'bg-emerald-100 text-emerald-800 ring-emerald-600/20',
  A2: 'bg-teal-100 text-teal-800 ring-teal-600/20',
  B1: 'bg-amber-100 text-amber-800 ring-amber-600/20',
  B2: 'bg-orange-100 text-orange-800 ring-orange-600/20',
  C1: 'bg-rose-100 text-rose-800 ring-rose-600/20',
  C2: 'bg-purple-100 text-purple-800 ring-purple-600/20',
}

function VocabularyCard({ entry }: VocabularyCardProps) {
  const levelStyle = LEVEL_STYLES[entry.level] ?? 'bg-slate-100 text-slate-800 ring-slate-600/20'

  return (
    <article
      aria-label={`Vocabulary word: ${entry.word}`}
      className="relative w-full max-w-xl rounded-2xl border border-stone-200 bg-[#fdfbf6] p-6 shadow-sm shadow-stone-200/60 sm:p-10"
    >
      <header className="flex items-start justify-between gap-4">
        <div>
          <h1 className="font-serif text-4xl font-semibold tracking-tight text-stone-900 sm:text-5xl">
            {entry.word}
          </h1>
          <p
            className="mt-2 font-mono text-sm text-stone-500 sm:text-base"
            aria-label={`Phonetic transcription: ${entry.phonetic}`}
          >
            {entry.phonetic}
          </p>
        </div>

        <span
          className={`inline-flex shrink-0 items-center rounded-full px-3 py-1 text-xs font-semibold uppercase tracking-wide ring-1 ring-inset sm:text-sm ${levelStyle}`}
          aria-label={`CEFR level ${entry.level}`}
        >
          {entry.level}
        </span>
      </header>

      <div className="mt-6 border-t border-stone-200 pt-6">
        <p className="text-xs font-semibold uppercase tracking-widest text-stone-400">
          Translation
        </p>
        <p className="mt-1 text-xl font-medium text-stone-800 sm:text-2xl">
          {entry.translation}
        </p>
      </div>

      <div className="mt-6 grid gap-4 sm:grid-cols-2">
        <div className="rounded-xl bg-stone-100/70 p-4">
          <p className="text-xs font-semibold uppercase tracking-widest text-stone-400">
            English example
          </p>
          <p className="mt-2 text-base leading-relaxed text-stone-700">
            {entry.exampleEnglish}
          </p>
        </div>

        <div className="rounded-xl bg-stone-100/70 p-4">
          <p className="text-xs font-semibold uppercase tracking-widest text-stone-400">
            French example
          </p>
          <p className="mt-2 text-base leading-relaxed text-stone-700">
            {entry.exampleFrench}
          </p>
        </div>
      </div>
    </article>
  )
}

export default VocabularyCard
