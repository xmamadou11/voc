import type { CEFRLevel, VocabularyWord } from '../types/vocabulary'

/**
 * Returns the vocabulary word with the given id, or undefined if not found.
 */
export function getWordById(
  vocabulary: VocabularyWord[],
  id: number,
): VocabularyWord | undefined {
  return vocabulary.find((entry) => entry.id === id)
}

/**
 * Returns all vocabulary words matching the given CEFR level.
 */
export function getWordsByLevel(
  vocabulary: VocabularyWord[],
  level: CEFRLevel,
): VocabularyWord[] {
  return vocabulary.filter((entry) => entry.level === level)
}

/**
 * Returns a random word from the vocabulary, or undefined if the
 * vocabulary is empty.
 */
export function getRandomWord(vocabulary: VocabularyWord[]): VocabularyWord | undefined {
  if (vocabulary.length === 0) {
    return undefined
  }

  const randomIndex = Math.floor(Math.random() * vocabulary.length)
  return vocabulary[randomIndex]
}
