export type CEFRLevel = 'A1' | 'A2' | 'B1' | 'B2' | 'C1' | 'C2'

export interface VocabularyWord {
  id: number
  word: string
  phonetic: string
  level: CEFRLevel
  translation: string
  exampleEnglish: string
  exampleFrench: string
}
